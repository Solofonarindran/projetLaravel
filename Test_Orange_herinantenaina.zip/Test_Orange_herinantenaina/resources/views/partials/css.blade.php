
<!-- ao @ public no misy ny assets -->
<link rel="stylesheet" href="/assets/vendors/themify-icons/css/themify-icons.css">
    <!-- Bootstrap + narindra main styles -->
<link rel="stylesheet" href="/assets/css/narindra.css">
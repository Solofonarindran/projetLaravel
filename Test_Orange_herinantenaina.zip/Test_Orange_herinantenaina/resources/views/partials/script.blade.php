	<!--ao @ public ny assets -->
    <!-- core  -->
    <script src="/assets/vendors/jquery/jquery-3.4.1.js"></script>
    <script src="/assets/vendors/bootstrap/bootstrap.bundle.js"></script>

    <!-- bootstrap 3 affix -->
    <script src="/assets/vendors/bootstrap/bootstrap.affix.js"></script>

    <!-- Isotope  -->
    <script src="/assets/vendors/isotope/isotope.pkgd.js"></script>
    
    
  
    <!-- js -->
    <script src="/assets/js/narindra.js"></script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    {{-- Abstract title --}}
    <title>@yield('title')</title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
   

    {{-- Add style particulary--}}
    @yield('styles')
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="40" id="home">

    <!--J'ai hérité cette page et alors il faut prédéfinir tous les contenus par le mot clé @yield
    Le but c'est de clarifier le structure de code -->


    <!-- c'est porte.blade.php qui l'hérite -->
    @yield('header')

    @yield('contents')

    @yield('footers')

   
    {{-- Abstract JS --}}
    @yield('scripts')
</body>
</html>
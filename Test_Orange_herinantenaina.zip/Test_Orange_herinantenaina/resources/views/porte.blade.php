
@extends('layout')

@section('styles')
    @include('partials.css')
@endsection



@section('header')

   @include('partials.header')
@endsection


@section('contents')

    @include('partials.contents')

@endsection


@section('footers')

    @include('partials.footers')

@endsection


@section('scripts')

     @include('partials.script')

@endsection
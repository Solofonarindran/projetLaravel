<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PortefolioController extends Controller
{
    public function portefolio(){

        return view('porte');
    }
}

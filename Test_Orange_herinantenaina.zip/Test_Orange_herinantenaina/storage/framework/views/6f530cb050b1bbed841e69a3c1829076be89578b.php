<!-- ======= Header ======= -->
<?php $__env->startSection('title'); ?>

    ApplyJob | Registre

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

    <link href="/assets/css/login-signup.css" rel="stylesheet">
        <!-- Favicons -->
    <link href="/assets/img/favicon.png" rel="icon">
    <link href="/assets/img/apple-touch-icon.png" rel="apple-touch-icon">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
        <a href="pages-login.html" class="logo d-flex align-items-center">
            <img src="/assets/img/favicon.png" alt="">
            <span class="">
        Enkidu
    </span>
        </a>
    </div>
    <!-- End Logo -->

    <nav class="header-nav ms-auto">
        <ul class="d-flex align-items-center">

            <li class="nav-item dropdown">
                <a class="nav-link nav-icon" href="pages-login.html">
                    <button class="btn btn-light rounded-pill d-flex align-items-center hadow-5">
                        <i class="bi bi-person"></i> <small class=""> &nbsp; Se connecter</small> 
                    </button>
                </a>
                <!-- End actif Icon -->

            </li>
            <!-- End actif Nav -->

            <li class="nav-item dropdown d-none d-lg-block">
                <a class="nav-link nav-icon" href="pages-register.html">
                    <button class="btn btn-outline-light rounded-pill d-flex align-items-center hadow-5">
                        <i class="bi bi-person-plus"></i> <small class="d-lg-block"> &nbsp; Creer un compte</small>
                    </button>
                </a>
                <!-- End actif Icon -->

            </li>
            <!-- End actif Nav -->

        </ul>
    </nav>
    <!-- End Icons Navigation -->

    </header>
<?php $__env->stopSection(); ?>
<!-- End Header -->

<?php $__env->startSection('contents'); ?>
    <main style="background: rgba(0, 63, 78, 0.603);">
    <div class="container">

        <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

                        <div class="d-flex justify-content-center py-3">
                            <a href="" class="logo d-flex align-items-center w-auto">
                                <span class="d-block" style="font-size: 50px;">
                                ApplyJob
                                </span>
                            </a>
                        </div>
                        <!-- End Logo -->

                        <div class="card mb-3">

                            <div class="card-body">

                                <div class="pt-2 pb-2">
                                    <h5 class="card-title text-center pb-0 fs-4">Créer un compte</h5>
                                    <p class="text-center small">Entrez vos details personnels pour creer un compte</p>
                                </div>

                                <?php if(session('error_email')): ?>

                                    <center class="alert alert-danger w-100 h-25">
                                            <?php echo e(session('error_email')); ?>

                                    </center>

                                <?php endif; ?>

                                <form class="row g-3"  action="<?php echo e(route('cust.reg')); ?>"  method="POST"  enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-step form-step-active">
                                        <div class="col-12 mb-3">
                                            <label for="yourName" class="form-label">Nom</label>
                                            <div class="input-group ">
                                                <span class="input-group-text" id="inputGroupPrepend"> <i class="bi bi-person"></i> </span>
                                                <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Saisir votre nom" id="yourEmail" >
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-12 mb-4">
                                            <label for="email" class="form-label">Prénom</label>
                                            <div class="input-group ">
                                                <span class="input-group-text" id="inputGroupPrepend"> <i class="bi bi-envelope-fill"></i> </span>
                                                <input type="text" name="firstname" class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Saisir votre prenom" id="yourEmail" >
                                               <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                     <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button type="button" class="btn btn-primary w-100 p-2 btn-next fs-6" id="register">Suivant</button>
                                        </div>
                                    </div>
                                    <div class="form-step">
                                        <div class="col-12 mb-3">
                                            <label for="yourName" class="form-label">Adresse email</label>
                                            <div class="input-group ">
                                                <span class="input-group-text" id="inputGroupPrepend"> <i class="bi bi-envelope-fill"></i> </span>
                                                <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Saisir votre adresse email" id="yourEmail" >
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                     <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-12 mb-4">
                                            <label for="email" class="form-label">Profil</label>
                                            <div class="input-group ">
                                                <span class="input-group-text" id="inputGroupPrepend"> <i class="bi bi-person-plus"></i> </span>
                                                <input type="file" name="profil" class="form-control <?php $__errorArgs = ['profil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                <?php $__errorArgs = ['profil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                     <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <button type="button" class="btn btn-primary w-100 p-2 btn-prev fs-6" id="register">Précedent</button>
                                            </div>
                                            <div class="col-6">
                                                <button type="button" class="btn btn-primary w-100 p-2 btn-next fs-6" id="register">Suivant</button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-step">
                                        <div class="col-12 mb-3">
                                            <label for="yourName" class="form-label">Mot de passe</label>
                                            <div class="input-group ">
                                                <span class="input-group-text" id="inputGroupPrepend"> <i class="bi bi-key"></i> </span>
                                                <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Saisir votre mot de passe" id="yourEmail" >
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                     <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-12 mb-3">
                                            <label for="yourPassword" class="form-label">Confimation le mot de passe</label>
                                            <div class="input-group ">
                                                <span class="input-group-text" id="inputGroupPrepend"> <i class="bi bi-key"></i> </span>
                                                <input type="password" name="password_confirm" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Confirmer votre mot de passe" id="yourEmail" >
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                     <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-12 mb-4">
                                            <div class="form-check">
                                                <input class="form-check-input" name="terms" type="checkbox" value="" id="acceptTerms" >
                                                <label class="form-check-label" for="acceptTerms">Accepter <a href="#" class="text-secondary">les terms et les conditions</a></label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-6">
                                                <button type="button" class="btn btn-primary w-100 p-2 btn-prev fs-6" id="register">Précedent</button>
                                            </div>
                                            <div class="col-6">
                                                <button class="btn btn-primary w-100 p-2 fs-6 " type="submit" id="register">Valider</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="progressbar">
                                        <div class="progress" id="progress"></div>

                                        <div class="progress-step progress-step-active" data-title="Information"></div>
                                        <div class="progress-step" data-title="Photo"></div>
                                        <div class="progress-step" data-title="Password"></div>
                                    </div>
                                    <hr>
                                    <div class="col-12">
                                        <p class="small mb-0">J'ai un compte. <a href="<?php echo e(route('view.login')); ?>">Se connecter</a></p>
                                    </div>
                                </form>

                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </section>

    </div>
    </main>
<?php $__env->stopSection(); ?>
<!-- End #main -->

<?php $__env->startSection('script'); ?>
    <script src="/assets/js/app.js"></script>
    <script src="/assets/js/main.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_office.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narindra/workspace/Apply_job/resources/views/front_office/registre.blade.php ENDPATH**/ ?>
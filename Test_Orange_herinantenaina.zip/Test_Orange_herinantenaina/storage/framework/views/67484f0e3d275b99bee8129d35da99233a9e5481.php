 <!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

<ul class="sidebar-nav" id="sidebar-nav">
    <li class="nav-item p-3">
        <center class="">
            <a class="" href="">
                <div class="aside-profile-online" style="display:flex; align-items:center; justify-content:center">
                        <?php if(Auth()->user()): ?>
                          
                                <img src="<?php echo e(Auth()->user()->media->path); ?>" alt="logo" srcset="">

                        <?php endif; ?>
                </div>
                <div class="profile-name">
                    <span class="badge badge-number online">Connecté</span>
                    <div class="text-secondary mt-2 p-2">
                        <?php if(Auth()->user()): ?>
                            <small>
                                <b class="text-uppercase"><?php echo e(Auth()->user()->name); ?></b>
                            </small><br>
                            <small><?php echo e(Auth()->user()->firstname); ?></small>
                        <?php endif; ?>
                    </div>
                </div>
            </a>
        </center>
    </li>
    <!-- End Nav -->
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('user.home')); ?>">
            <i class="bi bi-layout-text-window-reverse"></i>
            <span>Actualités</span>
        </a>
    </li>
    <!-- End Profile Page Nav -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#">
            <i class="bi bi-envelope"></i>
            <span>Messages</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="">
            <i class="bi bi-info-circle"></i>
            <span>Notifications</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('user.company')); ?>">
            <i class="bi bi-person"></i>
            <span>Compagnies</span>
        </a>
    </li>
    <!-- End Nav -->
    <hr>
    <li class="nav-heading">A propos</li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('user.profil')); ?>">
            <i class="bi bi-person"></i>
            <span>Mon profile</span>
        </a>
    </li>

    <!-- End Contact Page Nav -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#">
            <i class="bi bi-envelope"></i>
            <span>Contact</span>
        </a>
    </li>
    <!-- End Contact Page Nav -->

</ul>

</aside>
<!-- End Sidebar--><?php /**PATH /home/narindra/workspace/Apply_job/resources/views/front_office/partials/sidebar.blade.php ENDPATH**/ ?>
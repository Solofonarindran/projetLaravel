<?php $__env->startSection('style'); ?>
    <!-- Template Main CSS File -->
    <link href="/assets/css/style.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    ApplyJob | Profile
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contents'); ?>
        <main id="main" class="main">

        <div class="pagetitle">
            <h1>Mon Profile</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('user.home')); ?>">Home</a></li>
                    <li class="breadcrumb-item">Users</li>
                    <li class="breadcrumb-item active">Profile</li>
                </ol>
            </nav>
        </div>
        <!-- End Page Title -->

        <section class="section profile">
            <div class="row">
                <div class="col-xl-4">

                    <div class="card">
                        <div class="card-body profile-card pt-4 d-flex flex-column align-items-center">
                             <?php if(Auth()->user()): ?>
                                <img src="/<?php echo e(Auth()->user()->media->path); ?>" alt="Profile" class="rounded-circle">
                            
                                <h2><?php echo e(Auth()->user()->name); ?></h2><br>
                                <h3><?php echo e(Auth()->user()->firstname); ?></h3>
                            <?php endif; ?>
                           
                            <div class="social-links mt-2">
                                <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
                                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                                <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-xl-8">

                    <div class="card">
                        <div class="card-body pt-3">
                            <!-- Bordered Tabs -->
                            <ul class="nav nav-tabs nav-tabs-bordered">

                                <li class="nav-item">
                                    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#profile-overview">Overview</button>
                                </li>

                                <li class="nav-item">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#profile-edit">Modifier Profile</button>
                                </li>
                            </ul>
                            <div class="tab-content pt-2">

                                <div class="tab-pane fade show active profile-overview" id="profile-overview">
                                    <h5 class="card-title">Biographie</h5>
                                    <p class="small fst-italic">
                                        Sunt est soluta temporibus accusantium neque nam maiores 
                                        cumque temporibus. Tempora libero non est unde veniam est qui dolor.
                                         Ut sunt iure rerum quae quisquam autem eveniet perspiciatis odit. Fuga sequi sed ea saepe
                                        at unde.</p>

                                    <h5 class="card-title">Profile Details</h5>

                                   
                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label ">Nom </div>
                                        <div class="col-lg-9 col-md-8">
                                            <?php if(Auth()->user()): ?>
                                                <?php echo e(Auth()->user()->name); ?>

                                            <?php endif; ?>

                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label ">Prénom </div>
                                        <div class="col-lg-9 col-md-8">
                                            <?php if(Auth()->user()): ?>
                                                <?php echo e(Auth()->user()->firstname); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Activité</div>
                                        <div class="col-lg-9 col-md-8">
                                            <?php if(Auth()->user()): ?>
                                                <?php echo e(Auth()->user()->activity); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Pays</div>
                                        <div class="col-lg-9 col-md-8">
                                            <?php if(Auth()->user()): ?>
                                                <?php echo e(Auth()->user()->country); ?>

                                            
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Adresse</div>
                                        <div class="col-lg-9 col-md-8">
                                            <?php if(Auth()->user()): ?>
                                                <?php echo e(Auth()->user()->adress); ?>


                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Numéro mobile</div>
                                        <div class="col-lg-9 col-md-8">
                                            <?php if(Auth()->user()): ?>
                                                <?php echo e(Auth()->user()->phones); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-3 col-md-4 label">Email</div>
                                        <div class="col-lg-9 col-md-8">
                                            <?php if(Auth()->user()): ?>
                                                <?php echo e(Auth()->user()->email); ?>

                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>

                                <div class="tab-pane fade profile-edit pt-3" id="profile-edit">

                                    <!-- Profile Edit Form -->
                                    <form method="post" action="<?php echo e(route('user.updateprofile',['id'=>Auth()->user()->id])); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row mb-3">
                                            <label for="profileImage" class="col-md-4 col-lg-3 col-form-label">Profile Image</label>
                                            <div class="col-md-8 col-lg-9">
                                                <?php if(Auth()->user()): ?>
                                                     <img src="<?php echo e(Auth()->user()->media->path); ?>" alt="Profile">
                                                <?php endif; ?>
                                                <div class="pt-2">
                                                    <a href="#" class="btn btn-primary btn-sm" title="Upload new profile image"><i class="bi bi-upload"></i></a>
                                                    <a href="#" class="btn btn-danger btn-sm" title="Remove my profile image"><i class="bi bi-trash"></i></a>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="name" class="col-md-4 col-lg-3 col-form-label">Nom</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" value="<?php if(Auth()->user()): ?> <?php echo e(Auth()->user()->name); ?> <?php endif; ?>">

                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <label for="firstname" class="col-md-4 col-lg-3 col-form-label">Prénom</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="firstname" type="text" class="form-control <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="firstname" value="<?php if(Auth()->user()): ?> <?php echo e(Auth()->user()->firstname); ?> <?php endif; ?>">
                                                <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="biographie" class="col-md-4 col-lg-3 col-form-label">Biographie</label>
                                            <div class="col-md-8 col-lg-9">
                                                <textarea name="biographie" class="form-control" id="biographie" style="height: 100px"><?php if(Auth()->user()): ?> <?php echo e(Auth()->user()->biographie); ?> <?php endif; ?></textarea>
                                            </div>
                                        </div>

                                

                                        <div class="row mb-3">
                                            <label for="activity" class="col-md-4 col-lg-3 col-form-label">Activités</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="act" type="text" class="form-control d-none" id="act" value="<?php if(Auth()->user()): ?> <?php echo e(Auth()->user()->activity); ?> <?php endif; ?>">
                                                <select name="activity" id=""  style="height: 40px; border-radius: 3px;">
                                                        <option value="En attente">En attente. . .</option>
                                                        <?php $__currentLoopData = $domains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $domain): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($domain->domain); ?>"><?php echo e($domain->domain); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                </select>
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="Country" class="col-md-4 col-lg-3 col-form-label">Pays</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="country" type="text" class="form-control" id="Country" value="<?php if(Auth()->user()): ?> <?php echo e(Auth()->user()->country); ?> <?php endif; ?>">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="Address" class="col-md-4 col-lg-3 col-form-label">Adresse</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="adress" type="text" class="form-control" id="Address" value="<?php if(Auth()->user()): ?> <?php echo e(Auth()->user()->adress); ?> <?php endif; ?>">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="Phone" class="col-md-4 col-lg-3 col-form-label">Phone</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="phones" type="text" class="form-control" id="Phone" value="<?php if(Auth()->user()): ?> <?php echo e(Auth()->user()->phones); ?> <?php endif; ?>">
                                            </div>
                                        </div>

                                        <div class="row mb-3">
                                            <label for="Email" class="col-md-4 col-lg-3 col-form-label">Email</label>
                                            <div class="col-md-8 col-lg-9">
                                                <input name="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Email" value="<?php if(Auth()->user()): ?> <?php echo e(Auth()->user()->email); ?> <?php endif; ?>">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        

                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </div>
                                    </form>
                                    <!-- End Profile Edit Form -->

                                </div>

                            </div>
                        </div>

                    </div>
                </div>
        </section>

        </main>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('script'); ?>

    <script>
        $(document).ready(function(){

        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_office.layout_fils', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narindra/workspace/Apply_job/resources/views/front_office/profile.blade.php ENDPATH**/ ?>
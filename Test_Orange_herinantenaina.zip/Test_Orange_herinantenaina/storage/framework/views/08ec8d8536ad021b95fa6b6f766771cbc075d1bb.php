<?php $__env->startSection('title'); ?>
    ApplyJob | Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link href="/assets/css/home.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
        <main id="main" class="main">

        <div class="pagetitle">
            <h1>Les actualites</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('user.home')); ?>">Home</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('user.home')); ?>">Actualités</a> </li>
                </ol>
            </nav>
        </div>
        <!-- End Page Title -->
        <?php if($offres): ?>
            <?php $__currentLoopData = $offres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section class="section principale-actus">
                        <div class="row">
                            <!-- Left side columns -->
                            <div class="col-lg-8">
                                <div class="row">
                                    <!-- actualite Card -->
                                    <div class="col-xxl-12 col-xl-12">

                                        <div class="card info-card customers-card">
                                            <div class="card-body mt-3">

                                                <div class="d-flex align-items-center">
                                                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                                                        <a href="#">
                                                            <div class="profile-actus-online">
                                                                <img src="<?php echo e($offre->company->media->path); ?>" width="100%" alt="">
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="ps-3">
                                                        <a href="<?php echo e(route('user.offre',['id'=>$offre->id])); ?>">
                                                            <h6 class="details-title">Formation en developpement mobile gratuite pour les etudiants.</h6>
                                                        </a>
                                                        <div href="" class="text-muted small pt-2 ps-1 " style="letter-spacing:1px; font-weight:bold" >
                                                            Societé <?php echo e($offre->company->name); ?>  <span class="badge badge-number"><?php echo e($offre->offre_category->category); ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="footer-actus d-flex justify-content-between">
                                                    <div class="uptade mt-3">
                                                        <span class="text-muted small pt-4">
                                                             Mardi 12 septembre 2022
                                                        </span>
                                                    </div>

                                                </div>
                                                <div class="actualite-status mt-3">
                                                    <small>
                                                        <?php echo e($offre->description); ?>

                                                    </small> 
                                                    <a href="<?php echo e(route('user.offre',['id'=>$offre->id])); ?>" class="more-details">
                                                        <i class="bi bi-arrow-right text-primary"> Plus de details</i>
                                                    </a>

                                                </div>
                                                <!-- image actualite -->
                                                <div class="actualite-img mt-3">
                                                    <a href="#">
                                                        <img src="/assets/img/pexels-kampus-production-5940827.jpg" alt="" srcset="">
                                                    </a>
                                                </div>
                                                <!-- image actualite -->
                                                <div class="actualite-footer">
                                                    <div class="reagir">
                                                        
                                                        <button class="d-flex btn btn reaction" id="<?php echo e($offre->id); ?>">
                                                            <i class="bi bi-heart" id="reagir_heart"></i>&nbsp;

                                                            <?php if(is_null($offre->like)): ?>
                                                                <span class="nombre-reagir">aucune</span>&nbsp;
                                                                <span class="d-none d-sm-block">réaction</span>
                                                                <?php else: ?>
                                                                    <span class="nombre-reagir"><?php echo e($offre->like); ?></span>&nbsp;
                                                                    <span class="d-none d-sm-block">like</span>
                                                            <?php endif; ?>
                                                        </button>
                                                    </div>

                                                    <div class="share">
                                                        <button class="d-flex btn btn" data-bs-toggle="modal" data-bs-target="#modalShare">
                                                            <a href="<?php echo e(route('user.offre',['id'=>$offre->id])); ?>"><span>Postuler à cette offre</span></a>
                                                        
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <!-- End Customers Card -->
                            </div>
                        </div>
                        <!-- End Left side columns -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
            

            <!-- Right side columns -->
            <div class="col-xl-6">
                <div class="sidebar-right">
                    <!-- News & Updates Traffic -->
                    <div class="card">
                        <?php
                            $i=1;
                            $pub='';
                            $pub_collapse='';
                        ?>
                        <?php
                                    foreach($cvs as $cv){
                                        if(is_null($cv->dateAppointment)){
                                            $spancolor='bg-secondary';
                                            $message='<span class="badge rounded-pill bg-secondary">En attente..</span>';
                                            
                                        }else{
                                            $spancolor='bg-success';
                                            $message='<span class="badge rounded-pill bg-success pl-2">Entretient le '.$cv->dateAppointment.'</span>';
                                            
                                        }

                                        if($i<3){
                                            $pub='<div class="post-item clearfix" ">
                                                      <img src="'.$cv->offre->company->media->path.'" alt="" ">
                                                      <h4><a href="#">'.$cv->offre->domain.'</a></h4>

                                                      <div href="" class="text-muted small pt-1  " style="letter-spacing:1px; font-weight:bold" >
                                                        '.$cv->offre->company->name.'<span class="badge rounded-pill '.$spancolor.' m-2">'.$cv->offre->offre_category->category.'</span>
                                            
                                                      </div>
                                                      '.$message.'

                                               </div>
                                              <hr>'.$pub;


                                        }else{
                                            $pub_collapse='
                                                                            <div class="post-item clearfix ">
                                                                                <img src="'.$cv->offre->company->media->path.'" alt=" ">
                                                                                <h4><a href="# ">'.$cv->offre->domain.'</a></h4>
                                                                                <div href="" class="text-muted small pt-1  " style="letter-spacing:1px; font-weight:bold" >
                                                                                    '.$cv->offre->company->name.'<span class="badge rounded-pill '.$spancolor.' m-2">'.$cv->offre->offre_category->category.'</span>
                                                                        
                                                                                </div>
                                                                                '.$message.'
                                                                            </div>
                                                                            <hr>
                                 
                                                                        '.$pub_collapse;

                                        }
                                        
                                        
                                        
                                        $i+=1;

                                    }
                         ?>
                        <div class="card-body pb-0">
                            <h5 class="card-title">Offres postulés<span>| ApplyJob</span></h5>

                            <!-- sidebar recent posts-->
                            <div class="news" id="new-offre">
                                
                                 <?php
                                    echo($pub);
                                 ?>
                                
                                <div class="show-all">

                                    <a class="nav-link collapsed d-flex justify-content-end align-items-end" data-bs-target="#money-nav" data-bs-toggle="collapse" href="#">
                                        <span class="me-2">Voir plus</span><i class="bi bi-chevron-down ms-auto"></i>
                                    </a>
                                    <hr>
                                    <div id="money-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                                            <?php
                                                echo($pub_collapse);
                                            ?>
                                    </div>
                                </div>

                            </div>
                            <!-- End sidebar recent posts-->


                        </div>
                    </div>
                    <!-- End News & Updates -->
                </div>

            </div>
            <!-- End Right side columns -->

            </div>
        </section>

        </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script src="/assets/js/home.js"></script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('front_office.layout_fils', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narindra/workspace/Apply_job/resources/views/front_office/home_page.blade.php ENDPATH**/ ?>
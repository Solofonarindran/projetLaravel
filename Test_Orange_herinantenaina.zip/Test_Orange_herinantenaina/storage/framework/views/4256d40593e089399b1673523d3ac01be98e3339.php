<?php $__env->startSection('styles'); ?>
    <?php echo $__env->make('front_office.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Favicons -->
    <link href="/assets/img/favicon.png" rel="icon">
    <link href="/assets/img/apple-touch-icon.png" rel="apple-touch-icon">
    <!-- Template Main CSS File -->
    <?php echo $__env->yieldContent('style'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('front_office.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('front_office.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footers'); ?>

     <a href="# " class="back-to-top d-flex align-items-center justify-content-center "><i
      class="bi bi-arrow-up-short "></i></a>
    <?php echo $__env->yieldContent('footer'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <?php echo $__env->make('front_office.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script src="/assets/js/main.js "></script>
 
  <?php echo $__env->yieldContent('script'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front_office.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narindra/Emit L3/projetLaravel/resources/views/front_office/layout_fils.blade.php ENDPATH**/ ?>
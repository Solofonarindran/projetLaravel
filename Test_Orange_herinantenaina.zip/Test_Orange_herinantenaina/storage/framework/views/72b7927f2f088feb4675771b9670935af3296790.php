<!-- Vendor JS Files -->
   
    <script src="/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/jquery3-5-1.js"></script>
  
    <script src="/assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="/assets/vendor/tinymce/tinymce.min.js"></script>
  
  <!--  <script src="/assets/js/vendors.bundle.js"></script>
    <script src="/assets/js/app.bundle.js"></script> -->
    <?php /**PATH /home/narindra/Emit L3/projetLaravel/resources/views/front_office/partials/script.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <?php echo $__env->make('front_office.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <?php echo $__env->yieldContent('header'); ?>

    
    <?php echo $__env->yieldContent('sidebar'); ?>

    <?php echo $__env->yieldContent('contents'); ?>

    <?php echo $__env->yieldContent('footers'); ?>

    <?php echo $__env->make('front_office.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH /home/narindra/workspace/Apply_job/resources/views/front_office/layout.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    ApplyJob | Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
     <!-- Template Main CSS File -->
     <link href="/assets/css/style.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <!-- main -->
    <main id="main" class="main">

    <div class="pagetitle">
        <h1>Société</h1>
        <nav>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item">compagnie</li>
                <li class="breadcrumb-item active">Details</li>
            </ol>
        </nav>
    </div>
    <!-- End Page Title -->
    <section>
        <div class="row">
            <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-6">
                        <div class="card">
                            <div class="card-title d-flex justify-content-center align-items-center">
                                <h4 class="text-center fw-bold">Profil compagnie</h4>
                            </div>
                            <hr style="margin-top: -10px;">
                            <div class="card-body">
                                <div class="row">

                                    <div class="col-xl-8">
                                        <div class="row mb-3">
                                            <div class="col-lg-3 col-md-4 fw-bold text-primary">Nom</div>
                                            <div class="col-lg-9 col-md-8 text-uppercase"><?php echo e($company->name); ?></div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-lg-3 col-md-4 fw-bold text-primary">Adresse</div>
                                            <div class="col-lg-9 col-md-8"><?php echo e($company->adress); ?></div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-lg-3 col-md-4 fw-bold text-primary">Ville</div>
                                            <div class="col-lg-9 col-md-8"><?php echo e($company->town); ?></div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-lg-3 col-md-4 fw-bold text-primary">Email</div>
                                            <div class="col-lg-9 col-md-8"><?php echo e($company->email); ?></div>
                                        </div>

                                        <div class="row mb-3">
                                            <div class="col-lg-3 col-md-4 fw-bold text-primary">Contact</div>
                                            <div class="col-lg-9 col-md-8"><?php echo e($company->phone); ?></div>
                                        </div>

                                        

                                    </div>
                                    <div class="col-xl-4">
                                        <img src="<?php echo e($company->media->path); ?>" alt="" height="120px" width="150px" style="border-radius: 20px;">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            
        </div>
    </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_office.layout_fils', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narindra/workspace/Apply_job/resources/views/front_office/company.blade.php ENDPATH**/ ?>
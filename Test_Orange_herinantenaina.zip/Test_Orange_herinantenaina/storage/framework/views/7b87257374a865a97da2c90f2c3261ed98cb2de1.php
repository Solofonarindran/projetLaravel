<script src="/asset_facture/js/vendors.bundle.js"></script>
<script src="/asset_facture/js/app.bundle.js"></script>
<script src="/asset_facture/js/statistics/peity/peity.bundle.js"></script>
<script src="/asset_facture/js/statistics/flot/flot.bundle.js"></script>
<script src="/asset_facture/js/statistics/easypiechart/easypiechart.bundle.js"></script><?php /**PATH /home/narindra/Emit L3/projetLaravel/resources/views/facture/partials/script.blade.php ENDPATH**/ ?>
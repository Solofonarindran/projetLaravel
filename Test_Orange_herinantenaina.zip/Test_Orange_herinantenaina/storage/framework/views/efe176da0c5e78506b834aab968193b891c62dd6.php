<footer class="footer py-3">
        <div class="container">
            <p class="small mb-0 text-light">
                &copy; <script>document.write(new Date().getFullYear())</script> Created<i class="ti-heart text-danger"></i> By <a href="http://devcrud.com" target="_blank"><span class="text-danger" title="Bootstrap 4 Themes and Dashboards">Narindra</span></a> 
            </p>
        </div>
</footer><?php /**PATH /home/narindra/Test_Orange/resources/views/partials/footers.blade.php ENDPATH**/ ?>
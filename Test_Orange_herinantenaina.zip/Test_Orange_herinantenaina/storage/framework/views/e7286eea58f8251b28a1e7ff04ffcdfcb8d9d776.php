<?php $__env->startSection('title'); ?>
    ApplyJob | Offre
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
     <!-- Template Main CSS File -->
     <link href="/assets/css/style.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
        <!-- main -->
        <main id="main" class="main">

        <div class="pagetitle">
            <h1>Details</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('user.home')); ?>">Home</a></li>
                    <li class="breadcrumb-item">Offre</li>
                    <li class="breadcrumb-item active">Details</li>
                </ol>
            </nav>
        </div>
        <!-- End Page Title -->

        <section>
            <div class="row">
                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-title d-flex justify-content-center align-items-center">
                            <h4 class="text-center fw-bold">Profil récruteur</h4>
                        </div>
                        <hr style="margin-top: -10px;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-xl-4">
                                    <img src="<?php echo e($offre->company->Users->media->path); ?>" alt="" height="120px" width="150px" style="border-radius: 20px;">
                                </div>
                                <div class="col-xl-8">
                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Nom</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->Users->name); ?></div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Prénom</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->Users->firstname); ?></div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Adresse</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->Users->adress); ?></div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Email</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->Users->email); ?></div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Phone</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->Users->phones); ?></div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-title d-flex justify-content-center align-items-center">
                            <h4 class="text-center fw-bold">Profil compagnie</h4>
                        </div>
                        <hr style="margin-top: -10px;">
                        <div class="card-body">
                            <div class="row">

                                <div class="col-xl-8">
                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Nom</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->name); ?></div>
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Adresse</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->adress); ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Ville</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->town); ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Email</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->email); ?></div>
                                    </div>

                                   

                                    <div class="row mb-3">
                                        <div class="col-lg-4 col-md-4 fw-bold text-primary">Contact</div>
                                        <div class="col-lg-8 col-md-8"><?php echo e($offre->company->phone); ?></div>
                                    </div>

                                </div>
                                <div class="col-xl-4">
                                    <img src="<?php echo e($offre->company->media->path); ?>" alt="" height="120px" width="150px" style="border-radius: 20px;">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-title d-flex justify-content-center align-items-center">
                        <h4 class="fw-bold">Description offre</h4>
                    </div>
                    <hr style="margin-top: -10px;">
                    <div class="row">
                        <div class="col-xl-8" style="margin: left -10px;">


                            <h5 class="card-title fw-bold text-primary ms-2">Description</h5>
                            <hr style="margin-top: -15px;">
                            <p class="small fst-italic ms-2 mb-3">
                                <?php echo e($offre->description); ?>

                            </p>
                            <h5 class="card-title fw-bold text-primary ms-2 text-center">Details offre</h5>
                            <hr style="margin-top: -15px;">
                            <div class="row">
                                <div class="col-xl-12">
                                    <div class="row mb-3">
                                        <div class="col-lg-4 fw-bold text-primary">Titre</div>
                                        <div class="col-lg-8 ">ADMINISTRATION EN RESEAUX</div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-lg-4 fw-bold text-primary">Catégorie</div>
                                        <div class="col-lg-8 "><?php echo e($offre->offre_category->category); ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-lg-4 fw-bold text-primary">Budget</div>
                                        <div class="col-lg-8 "><?php echo e($offre->devise); ?> <?php echo e($offre->salary); ?></div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-lg-4 fw-bold text-primary">Durée</div>
                                        <div class="col-lg-8 "><?php echo e($offre->deadline); ?></div>
                                    </div>
                                </div>
                                <div class="col-xl-12">
                                    <!-- <h6 class="card-title fw-bold text-primary" style="margin-top: -20px;">Compétence</h6>
                                    <p></p><br> -->
                                    <div class="row mb-3 ">
                                        <div class="col-lg-4 fw-bold text-primary">Compétence</div>
                                        <div class="col-lg-8"><?php echo e($offre->anne_experence); ?></div>

                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-lg-4 fw-bold text-primary">Domaine</div>
                                        <div class="col-lg-8"><?php echo e($offre->domain); ?></div>

                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="col-xl-4">
                            <div class="card">
                                <div class="card-title d-flex justify-content-center align-items-center">
                                    <h5 class="fw-bold text-dark">Formulaire</h5>

                                </div>
                            </div>
                            <form action="<?php echo e(route('post.cv')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">

                                    <div class="col-12 mb-3">
                                        <label for="email" class="form-label fw-bold text-primary">Domaine</label>

                                        <input type="text" value="<?php echo e($offre->domain); ?>" name="domain" class="form-control <?php $__errorArgs = ['domain'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" disabled >
                                        <input type="text" value="<?php echo e($offre->domain); ?>" name="domain" class="d-none">
                                        <input type="text" value="<?php echo e($offre->id); ?>" name="offre_id" class="d-none">
                                    </div>
                                    <div class="col-12 mb-3">
                                        <label for="email" class="form-label fw-bold text-primary">Specialité</label>
                                        <select name="speciality_id" id="" class="w-100 <?php $__errorArgs = ['speciality_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="height: 40px; border-radius: 3px;">
                                            <option value="">Choisir votre spécialité . . .</option>
                                             <?php $__currentLoopData = $specialitys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <option value="<?php echo e($speciality->id); ?>"><?php echo e($speciality->speciality); ?></option>
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </select>
                                        <?php $__errorArgs = ['speciality_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                           <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12">
                                        <label for="email" class="form-label fw-bold text-primary">Niveau</label>
                                        <select name="level" id="" class="w-100 <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="height: 40px; border-radius: 3px;">
                                            <option value="">Choisir votre niveau . . .</option>
                                            <option value="beginner">Débutant</option>
                                            <option value="normal">Normal</option>
                                            <option value="advance">Avancé</option>
                                        </select>
                                        <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                           <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12">
                                        <label for="" class="form-label fw-bold text-primary">Description</label>
                                        <textarea name="description" class="<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" cols="30" rows="5"></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                           <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <hr>

                                    <h6 class="text-center text-dark fw-bold">Pièce jointe</h6>
                                    <div class="col-12 mb-3">
                                        <label for="" class="form-label fw-bold text-primary">Titre</label>
                                        <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"   id="" placeholder="Saisir le titre de dossier"> 
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                           <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12 mb-3">
                                        <label for="media" class="form-label fw-bold text-primary">Votre CV</label>
                                        <input type="file" name="cv" class="form-control <?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="">
                                        <?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                           <center class="alert alert-danger w-100"><?php echo e($message); ?></center>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                </div>
                                <div class="card-footer">
                                    <div class="row d-flex justify-content-between align-items-center">
                                        <div class="col-xl-6 d-flex justify-content-center">
                                            <button type="reset" class="btn btn-outline-primary rounded-pill w-75">Annuler</button>
                                        </div>
                                        <div class="col-xl-6 d-flex justify-content-center">
                                            <button type="submit" class="btn btn-outline-success rounded-pill w-75">Envoyer</button>
                                        </div>


                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </section>
        </main>
        <!-- end main -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <footer id="footer" class="footer">
        <div class="credits text-dark">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
            Designed by <a href="#">ApplyJob</a>
        </div>
    </footer>
    <!-- End Footer -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front_office.layout_fils', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/narindra/workspace/Apply_job/resources/views/front_office/detail_offre.blade.php ENDPATH**/ ?>
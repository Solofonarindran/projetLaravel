  
 <!-- Vendor CSS Files -->
    <link href="/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/Aeonik/css/fonts.css">
   


   <!-- <link rel="stylesheet" media="screen, print" href="/assets/css/vendors.bundle.css">
    <link rel="stylesheet" media="screen, print" href="/assets/css/app.bundle.css">--><?php /**PATH /home/narindra/Emit L3/projetLaravel/resources/views/front_office/partials/css.blade.php ENDPATH**/ ?>
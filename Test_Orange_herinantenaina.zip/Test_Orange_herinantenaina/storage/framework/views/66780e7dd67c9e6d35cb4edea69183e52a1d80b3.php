
<link rel="stylesheet" media="screen, print" href="/asset_facture/css/vendors.bundle.css">
<link rel="stylesheet" media="screen, print" href="/asset_facture/css/app.bundle.css">
<link rel="stylesheet" media="screen, print" href="/asset_facture/css/page-invoice.css"><?php /**PATH /home/narindra/Emit L3/projetLaravel/resources/views/facture/partials/css.blade.php ENDPATH**/ ?>